
import axios from 'axios';
import type { ChatResponse } from './types/chat.ts';

// Simulated delay to mimic real API behavior
const MOCK_DELAY = 500;

class MockApiService {
    private abortController: AbortController | null = null;

    async sendMessage(message: string): Promise<ChatResponse> {
        // Create new AbortController for this request
        this.abortController = new AbortController();

        try {
            // Simulate streaming response with artificial delay
            await new Promise((resolve) => setTimeout(resolve, MOCK_DELAY));

            // Mock response
            const response: ChatResponse = {
                id: Math.random().toString(36).substring(7),
                content: `This is a mock response to: "${message}". In a real implementation, this would be connected to your backend API.`,
                isCompleted: true
            };

            return response;
        } catch (error) {
            if (axios.isCancel(error)) {
                throw new Error('Request was cancelled');
            }
            throw error;
        }
    }

    cancelRequest() {
        if (this.abortController) {
            this.abortController.abort();
            this.abortController = null;
        }
    }
}

export const mockApiService = new MockApiService();
