import { MantineProvider } from '@mantine/core';
import { ChatBot } from './components/ChatBot';
import '@mantine/core/styles.css';

function App() {
  return (
    <MantineProvider>
      <ChatBot />
    </MantineProvider>
  );
}

export default App;
