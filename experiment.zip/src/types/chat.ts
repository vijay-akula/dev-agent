export interface ChatMessage {
    id: string;
    content: string;
    isUser: boolean;
    timestamp: Date;
    copied?: boolean; // Optional property to track copy status
}

// Update ChatSettings type to accept FileSystemDirectoryHandle
export type ChatSettings = {
    downloadFolder: FileSystemDirectoryHandle | null; // Allow null for initial state
};

export interface ChatResponse {
    id: string;
    content: string;
    isCompleted: boolean;
}
