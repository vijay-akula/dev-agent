import { useState, useRef, useEffect } from 'react';
import {
    Box,
    Text,
    TextInput,
    Button,
    Group,
    Stack,
    Paper,
    ScrollArea,
    ActionIcon,
    Modal,
    LoadingOverlay,
} from '@mantine/core';
import { IconDownload, IconSettings, IconCopy, IconSend, IconEyePause, IconMenu2 } from '@tabler/icons-react';
import { mockApiService } from '../services/mockApiService.ts';

// Define the ChatMessage type
type ChatMessage = {
    id: string;
    content: string;
    isUser: boolean;
    timestamp: Date;
    copied?: boolean; // Added copied property
    downloaded?: boolean; // Added downloaded property
};

// Define the ChatSettings type
type ChatSettings = {
    downloadFolder: FileSystemDirectoryHandle | null;
};


export function ChatBot() {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [settings, setSettings] = useState<ChatSettings>({ downloadFolder: null });
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isSystemContextOpen, setIsSystemContextOpen] = useState(false);
    const [systemContext, setSystemContext] = useState('');
    const viewportRef = useRef<HTMLDivElement>(null);

    // Auto scroll to bottom when new messages arrive
    useEffect(() => {
        if (viewportRef.current) {
            viewportRef.current.scrollTo({
                top: viewportRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    }, [messages]);

    const handleSendMessage = async () => {
        if (!inputValue.trim() || isProcessing) return;

        const userMessage: ChatMessage = {
            id: Math.random().toString(36).substring(7),
            content: inputValue.trim(),
            isUser: true,
            timestamp: new Date()
        };

        const thinkingMessage: ChatMessage = {
            id: Math.random().toString(36).substring(7),
            content: 'thinking.',
            isUser: false,
            timestamp: new Date()
        };

        setMessages(prev => [...prev, userMessage, thinkingMessage]);
        setInputValue('');
        setIsProcessing(true);

        let dotCount = 1;
        const intervalId = setInterval(() => {
            dotCount = (dotCount % 3) + 1;
            setMessages(prev => prev.map(msg => msg.id === thinkingMessage.id ? {
                ...msg,
                content: `thinking${'.'.repeat(dotCount)}`
            } : msg));
        }, 500);

        try {
            const response = await mockApiService.sendMessage(userMessage.content, systemContext);

            const botMessage: ChatMessage = {
                id: response.id,
                content: response.content,
                isUser: false,
                timestamp: new Date()
            };

            clearInterval(intervalId);
            setMessages(prev => prev.map(msg => msg.id === thinkingMessage.id ? botMessage : msg));
        } catch (error) {
            clearInterval(intervalId);
            if (error instanceof Error && error.message === 'Request was cancelled') {
                setMessages(prev => prev.map(msg => msg.id === thinkingMessage.id ? {
                    id: Math.random().toString(36).substring(7),
                    content: 'Message processing was cancelled.',
                    isUser: false,
                    timestamp: new Date()
                } : msg));
            } else {
                setMessages(prev => prev.map(msg => msg.id === thinkingMessage.id ? {
                    id: Math.random().toString(36).substring(7),
                    content: 'An error occurred while processing your message.',
                    isUser: false,
                    timestamp: new Date()
                } : msg));
            }
        } finally {
            setIsProcessing(false);
        }
    };

    // Update usages of settings.downloadFolder to match updated type
    const handleDownload = async (message: ChatMessage) => {
        if (!settings.downloadFolder) {
            setIsSettingsOpen(true);
            return;
        }

        try {
            const blob = new Blob([message.content], { type: 'text/plain' });
            const fileHandle = await settings.downloadFolder.getFileHandle(
                `chat-message-${message.timestamp.toISOString().replace(/[:.]/g, '-')}.txt`,
                { create: true }
            );

            const writable = await fileHandle.createWritable();
            await writable.write(blob);
            await writable.close();

            console.log('File saved successfully to the selected folder.');
        } catch (error) {
            console.error('Failed to download message:', error);
        }
    };

    // Correct Mantine props and File System Access API usage
    const handleFolderSelection = async () => {
        if (!window.showDirectoryPicker) {
            console.error('Folder selection is not supported in this browser.');
            return;
        }

        try {
            const directoryHandle = await window.showDirectoryPicker();
            setSettings((prevSettings) => ({ ...prevSettings, downloadFolder: directoryHandle }));
        } catch (error) {
            console.error('Failed to select folder:', error);
        }
    };

    return (
        <Box p="md" style={{ maxWidth: '800px', margin: '0 auto' }}>
            <Paper shadow="sm" p="md" style={{ height: 'calc(100vh - 100px)' }}>
                <Stack h="100%">
                    <Group position="right">
                        <ActionIcon 
                            onClick={() => setIsSettingsOpen(true)}
                            size="lg"
                            variant="light"
                        >
                            <IconSettings size="1.2rem" />
                        </ActionIcon>
                        <ActionIcon 
                            onClick={() => setIsSystemContextOpen((prev) => !prev)}
                            size="lg"
                            variant="light"
                        >
                            <IconMenu2 size="1.2rem" />
                        </ActionIcon>
                    </Group>

                    {isSystemContextOpen && (
                        <Box style={{ padding: '1rem', border: '1px solid #eaeaea', borderRadius: '8px', marginBottom: '1rem', backgroundColor: '#f8f9fa' }}>
                            <TextInput
                                placeholder="Enter system context..."
                                value={systemContext}
                                onChange={(e) => setSystemContext(e.target.value)}
                                style={{ marginBottom: '0.5rem' }}
                            />
                            <Button onClick={() => setIsSystemContextOpen(false)} size="sm" variant="light">
                                Save
                            </Button>
                        </Box>
                    )}

                    <ScrollArea 
                        style={{ flex: 1 }} 
                        viewportRef={viewportRef}
                        offsetScrollbars
                    >
                        <Stack gap="md">
                            {messages.map((message) => (
                                <Paper
                                    key={message.id}
                                    p="sm"
                                    radius="md"
                                    style={{
                                        backgroundColor: message.content.startsWith('thinking') ? '#fff3cd' : message.isUser ? '#f1f3f5' : '#e7f5ff',
                                        marginLeft: message.isUser ? 'auto' : '0',
                                        marginRight: message.isUser ? '0' : 'auto',
                                        maxWidth: '80%',
                                        fontStyle: message.content.startsWith('thinking') ? 'italic' : 'normal',
                                        textAlign: message.content.startsWith('thinking') ? 'center' : 'left'
                                    }}
                                >
                                    <Group align="center" gap="xs">
                                        <Text size="sm" style={{ whiteSpace: 'pre-wrap' }}>
                                            {message.content}
                                        </Text>
                                        {!message.isUser && !message.content.startsWith('thinking') && (
                                            <>
                                                <ActionIcon
                                                    onClick={async () => {
                                                        await handleDownload(message);
                                                        setMessages(prev => prev.map(msg => msg.id === message.id ? {
                                                            ...msg,
                                                            downloaded: true
                                                        } : msg));

                                                        setTimeout(() => {
                                                            setMessages(prev => prev.map(msg => msg.id === message.id ? {
                                                                ...msg,
                                                                downloaded: false
                                                            } : msg));
                                                        }, 2000); // Remove "Downloaded!" message after 2 seconds
                                                    }}
                                                    size="sm"
                                                    variant="subtle"
                                                >
                                                    <IconDownload size="1rem" />
                                                </ActionIcon>
                                                <ActionIcon
                                                    onClick={() => {
                                                        navigator.clipboard.writeText(message.content);
                                                        setMessages(prev => prev.map(msg => msg.id === message.id ? {
                                                            ...msg,
                                                            copied: true
                                                        } : msg));

                                                        setTimeout(() => {
                                                            setMessages(prev => prev.map(msg => msg.id === message.id ? {
                                                                ...msg,
                                                                copied: false
                                                            } : msg));
                                                        }, 2000); // Remove "Copied!" message after 2 seconds
                                                    }}
                                                    size="sm"
                                                    variant="subtle"
                                                >
                                                    <IconCopy size="1rem" />
                                                </ActionIcon>
                                                {message.copied && (
                                                    <Text size="xs" color="green" style={{ marginLeft: '0.5rem' }}>
                                                        Copied!
                                                    </Text>
                                                )}
                                                {message.downloaded && (
                                                    <Text size="xs" color="green" style={{ marginLeft: '0.5rem' }}>
                                                        Downloaded!
                                                    </Text>
                                                )}
                                            </>
                                        )}
                                    </Group>
                                </Paper>
                            ))}
                        </Stack>
                    </ScrollArea>

                    <Group align="center" gap="xs" style={{ padding: '1rem', borderTop: '1px solid #eaeaea', alignItems: 'center', backgroundColor: '#f8f9fa' }}>
                        <TextInput
                            placeholder="Type your message..."
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            style={{ flex: 1, height: '3.5rem', borderRadius: '25px', padding: '0.75rem 1rem', fontSize: '1rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)' }}
                            disabled={isProcessing}
                        />
                        <ActionIcon
                            onClick={() => {
                                if (isProcessing) {
                                    mockApiService.cancelRequest();
                                    setIsProcessing(false);
                                } else {
                                    handleSendMessage();
                                }
                            }}
                            size="lg"
                            variant="filled"
                            color="blue"
                            style={{ borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', width: '3.5rem', height: '3.5rem', boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)' }}
                        >
                            {isProcessing ? <IconEyePause size="1.5rem" /> : <IconSend size="1.5rem" />}
                        </ActionIcon>
                    </Group>
                </Stack>
            </Paper>

            <Modal
                opened={isSettingsOpen}
                onClose={() => setIsSettingsOpen(false)}
                title="Chat Settings"
            >
                <Stack>
                    <Button onClick={handleFolderSelection}>Select Download Folder</Button>
                    <TextInput
                        label="Selected Folder"
                        value={settings.downloadFolder ? settings.downloadFolder.name : ''}
                        readOnly
                    />
                    <Button onClick={() => setIsSettingsOpen(false)}>Save</Button>
                </Stack>
            </Modal>
        </Box>
    );
}
